 const mondayService = require('./services');
//const transformer = require('./transformer')
//const wn = require('./c_to_l')  // wn word to number

async function executeAction(req, res) {
  const { shortLivedToken } = req.session;
  const { payload } = req.body;

  try {
    const { inputFields } = payload;
    const {boardId,itemId, columnId, columnCRT1,columnCRT2,columnCRT3, columnDEPOT } = inputFields;
    console.log(inputFields)
    const criters = await mondayService.get_cin_tp(shortLivedToken, itemId, columnCRT1 , columnCRT2, columnCRT3);
    let crt1_col = criters[0].id
    let crt1_val = criters[0].text
    let crt2_col = criters[1].id
    let crt2_val = criters[1].text
    console.log(crt1_col, crt1_val, crt2_col, crt2_val)
    const rslt = await mondayService.getCumul2(shortLivedToken,boardId,columnId,crt1_col,crt1_val,crt2_col,crt2_val) 
    console.log(rslt)  // token, brdId, itemId, columnDEPOT, value
   // await mondayService.depot_cumul_SNF2(shortLivedToken,boardId,itemId,columnDEPOT,(rslt.tot).toString()) // rslt.tot.toString()
    rslt.tab_ids.map(j=> {
        if(j == itemId){
                    mondayService.depot_cumul_SNF2(shortLivedToken,boardId,j,columnDEPOT,(rslt.tot).toString()) 
            //console.log("yes")
                }else{
                 mondayService.depot_cumul_SNF2(shortLivedToken,boardId,j,columnDEPOT,(0).toString())
               // console.log("no")
           }
  })
    /*
    const cumul = await mondayService.getCumul(shortLivedToken, itemId, columnId, columnCRT1,columnCRT2,columnCRT3  );
    const criters = await mondayService.get_cin_tp(shortLivedToken, itemId,columnCRT1,columnCRT2,columnCRT3  );     
    console.log("CUMUL => ", cumul )
    
    if (infos[0]!= ""){
    const existe = await mondayService.existeOuPas(shortLivedToken,infos[0],infos[1],infos[2])
    console.log( "ça existe ? ", existe)
    await mondayService.changeColumnValue(shortLivedToken, boardId, itemId, columnTarget, existe);
    
   }*/
    return res.status(200).send({});
  } catch (err) {
    console.error(err);
    return res.status(500).send({ message: 'internal server error' });
  }
}
/*
async function executeAction2(req, res) {
  const { shortLivedToken } = req.session;
  const { payload } = req.body;

  try {
    const { inputFields } = payload;
    const {boardId,itemId, columnId, columnRechId ,columnBrd ,columnTarget, columnIndq,duel } = inputFields;
    console.log(inputFields)
    const infos = await mondayService.getColumnValue(shortLivedToken, itemId, columnIndq, columnRechId, columnBrd,  );
         
    console.log("SEEK A VALUE => ",infos[0],"  ", infos[1], " ", infos[2] )
    
    if (infos[0]!= ""){
    const existe = await mondayService.existeOuPas2(shortLivedToken,infos[0],infos[1],infos[2],duel)
    console.log( "ça existe ? ", existe)
    await mondayService.changeColumnValue(shortLivedToken, boardId, itemId, columnTarget, existe);
   }
    return res.status(200).send({});
  } catch (err) {
    console.error(err);
    return res.status(500).send({ message: 'internal server error' });
  }
}
*/

async function executeAction2(req, res) {
  const { shortLivedToken } = req.session;
  const { payload } = req.body;

  try {
    const { inputFields } = payload;
    console.log("DATA MAGICIAN => ", inputFields )
    console.log("token  => ",   shortLivedToken)
    const {boardCtx,boardId, itemId, colID, columnTarget, columnIndq, duel} = inputFields;
    console.log(" BRDID ext => ", boardId)
    console.log(" ITEMID => ",itemId)
    console.log(" COLID ext => ", colID.value )
    console.log(" COL TRGT => ", columnTarget)
    console.log(" COL RECH => ", columnIndq)
    console.log(" DUEL => ", duel)
    //console.log(inputFields)
    const infos = await mondayService.getColumnValue3(shortLivedToken, itemId, columnIndq  );
         
    console.log("SEEK A VALUE => ",infos[0]," BOARDID EXT =>  ", boardId , " COL ID EXT => ", colID.vallue )    /// //"  ", infos[1], " ", infos[2] )
    
    if (infos[0]!= ""){
    const existe = await mondayService.existeOuPas2(shortLivedToken,infos[0],boardId,colID.value,duel)
    console.log( "ça existe ? ", existe)
    await mondayService.changeColumnValue(shortLivedToken, boardCtx, itemId, columnTarget, existe);
   }
    return res.status(200).send({});
  } catch (err) {
    console.error(err);
    return res.status(500).send({ message: 'internal server error' });
  }
}

async function executeAction21(req, res) {
  const { shortLivedToken } = req.session;
  const { payload } = req.body;
  console.log( "lived TOKEN  : " , shortLivedToken)
  console.log( "Session  : " , req.session)
  console.log( "LE PAYLOAD col : " , payload)
  const {dependencyData} = payload 
  console.log("BOARD IDEP => ",dependencyData.boardId)
  const {boardId} = dependencyData
  //const {boardId} = dependencyData
  console.log("la valeur dep :", boardId)//dependencyData.boardId
  try {
    //const { inputFields } = payload;
    //const {boardId,itemId, columnId, columnRechId ,columnBrd ,columnTarget, columnIndq } = inputFields;
    let columns = []
    columns = await mondayService.getAllColumns(shortLivedToken, boardId );
   // console.log("SEEK All COLUMNS monday.com => ", columns)
        
    // return res.status(200).send(   [ { title:'100' , value:'cent' }, { title:'200' , value:'deux cent' },{ title:'300' , value:'trois cent' }  ]    );
    return res.status(200).send( columns );
  } catch (err) {
    console.error(err);
    return res.status(500).send({ message: 'internal server error' });
  }
}

module.exports = {
  executeAction,
  executeAction2,
  executeAction21
};
